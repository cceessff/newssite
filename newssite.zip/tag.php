<?php
/**
 * Created by PhpStorm.
 * User: Dylan.L
 * Date: 2019/5/27
 * Time: 13:26
 */
$tag_get = urldecode($_GET['tag']);


$CONFIG = include 'config.php';
include 'Mongo.php';

$site_name = $CONFIG['site_name'];
$site_url = $CONFIG['site_url'];
$nav = $CONFIG['nav'];//导航
$db = new MongoDao($CONFIG['db']);

$news_list = $db->getNewsByTag($tag_get);

$site_title = $tag_get . "_" . $site_name;
$keyword = "$tag_get,$site_name";
$description = "$tag_get,$site_name";

$categorys = array_values($nav);
$hot_news = $db->getNews($categorys, 20, 0);//获取最新新闻

$tags = array();//标签
foreach ($news_list as $k => $v) {
    $tagarr = $v['tags'];
    if (is_array($tagarr)){
        foreach ($tagarr as $item) {
            if (isset($tags[$item])) {
                $tags[$item] += 1;
            } else {
                $tags[$item] = 1;
            }
        }
    }



}
arsort($tags);
$tags = array_slice($tags, 0, 30);
$tags = array_keys($tags);//最终标签
$page_str = '';
$js=isset($CONFIG['js'])?$CONFIG['js']:"";
$category_name = $tag_get;
header("Referrer-Policy: no-referrer");
include "views/list.php";

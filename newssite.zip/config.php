<?php

return array(
    'db' => array(
        'database' => 'news',
        'username' => 'news_user',
        'password' => 'Irk818$#12',
        'port' => 27017,
        'host' => '127.0.0.1',
    ),

    'nav'=>array(
        'history'=>'历史',
        'science'=>'科学',
        'mil'=>'军事',
        'digi'=>'数码',
        'astro'=>'星座'
    ),
    'keyword'=>'热门资讯,文章阅读,推荐文章,好文章',
    'description'=>'',
    'site_name'=>'幽幽资讯阅读网',
    'site_url'=>'http://www.newssite.com/',
    "js"=>"<script src=\"a.js\"></script>"


);

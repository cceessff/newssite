<?php
/**
 * Created by PhpStorm.
 * User: Dylan.L
 * Date: 2019/5/26
 * Time: 9:36
 */
$news_id = $_GET['id'];
if (file_exists("cache/{$news_id}.html")){
    header("Referrer-Policy: no-referrer");
    $content=file_get_contents("cache/{$news_id}.html");
    echo $content;
    exit;
}
use Overtrue\Pinyin\Pinyin;
include "vendor/autoload.php";
$CONFIG = include "config.php";
include "Mongo.php";
include_once 'phpanalysis/phpanalysis.class.php';
$site_name = $CONFIG['site_name'];
$site_url = $CONFIG['site_url'];
$db = new MongoDao($CONFIG['db']);
$news_id = $_GET['id'];
$news = $db->getNewsById($news_id);
$category = $news['category'];
$category_chn = $news['category_chn'];
$publish_time = date("Y-m-d H:i:s", $news['publish_time']);
$source = $news['source'];
$news_content = $news['content'];
$news_title = $news['title'];
$keyword = implode(',',$news['keywords']);
$description = $news['intro'];
$site_title = $news['title'] . "_" . $site_name;
$relate_tags = $news['tags'];
$nav = $CONFIG['nav'];//导航
$news_content=genKeywordLink($db,$news_content,$news['keywords'],$_SERVER['HTTP_HOST'],$news['article_id']);
$news_content=genPinyin($news_content);

$recommandCategory = array_rand($nav);
$recommandCategory=$nav[$recommandCategory];
$recommandNews = $db->getRecommandNews($recommandCategory);
$relate_news = array();
if (count($relate_tags) > 0) {
    $relate_news = $db->getRelateNews($relate_tags);
}
$categorys = array_values($nav);
$hot_news = $db->getNews($categorys, 20, 0);//获取最新新闻


$tags = array();//标签
foreach ($recommandNews as $k => $v) {
    $tagarr = $v['tags'];
    if (is_array($tagarr)) {

        foreach ($tagarr as $item) {
            if (isset($tags[$item])) {
                $tags[$item] += 1;
            } else {
                $tags[$item] = 1;
            }
        }

    }
}
foreach ($relate_news as $k => $v) {
    $tagarr = $v['tags'];
    if (is_array($tagarr)) {
        foreach ($tagarr as $item) {
            if (isset($tags[$item])) {
                $tags[$item] += 1;
            } else {
                $tags[$item] = 1;
            }
        }

    }
    $relate_news[$k]['publish_time'] = date('Y-m-d H:i:s', $v['publish_time']);
}
arsort($tags);
$tags = array_slice($tags, 0, 30);
$tags = array_keys($tags);//最终标签
$js=isset($CONFIG['js'])?$CONFIG['js']:"";
header("Referrer-Policy: no-referrer");
ob_start();

include "views/detail.php";
$content=ob_get_clean();
if (!is_dir("cache")){
    mkdir("cache",0777,true);
}
file_put_contents("cache/{$news_id}.html",$content);
echo $content;





function genPinyin($content){
    $stripcontent=strip_tags($content);
    PhpAnalysis::$loadInit = false;
    $pa = new PhpAnalysis('utf-8', 'utf-8', false);
    $pa->LoadDict();
    $pa->SetSource($stripcontent);
    $pa->differMax = false;
    $pa->unitWord = true;
    $pa->StartAnalysis(true);
    $keywords = $pa->GetFinallyKeywords();
    $keywords=explode(',',$keywords);
    $pinyin_service=new Pinyin();
    foreach ($keywords as $keyword){

        $pinyin=$pinyin_service->sentence($keyword,PINYIN_TONE);
        $replace="<ruby>{$keyword}<rp>[</rp><rt>{$pinyin}</rt><rp>]</rp></ruby>";
        $content=str_replace_once($keyword,$replace,$content);
    }
    return $content;

}




function genKeywordLink($db, $content,$keywords, $host, $id)
{
    foreach ($keywords as $key) {
        if ($key){
            $result = $db->getNewsByKeyword($key, $id);
            $replace = $key;

            if ($result) {
                $link = 'http://' . $host . '/content/' . $result['article_id'] . '.html';
                $replace = '<a href="' . $link . '">' . $key . '</a>';
            }
            $content = str_replace_once($key, $replace, $content);
        }

    }
    return $content;
}

/**
 *字符串只替换一次函数
 **/
function str_replace_once($needle, $replace, $haystack) {
    $pos = strpos($haystack, $needle);
    if ($pos === false) {
        return $haystack;
    }
    return substr_replace($haystack, $replace, $pos, strlen($needle));
}
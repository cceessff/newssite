<?php
/**
 * Created by PhpStorm.
 * User: Dylan.L
 * Date: 2019/5/25
 * Time: 8:49
 */
$CONFIG=include 'config.php';
//include 'DB.php';
include 'Mongo.php';
$db=new MongoDao($CONFIG['db']);

$nav=$CONFIG['nav'];//导航
$category=array_values($nav);
$news=$db->getNews($category,55,0);//获取最新新闻

$tags=array();//标签
foreach ($news as $k=>$v){
    $tagarr=$v['tags'];
    foreach ($tagarr as $item){
            if (isset($tags[$item])){
                $tags[$item]+=1;
            }else{
                $tags[$item]=1;
            }
        }

    $news[$k]['publish_time']=date('Y-m-d H:i:s',$v['publish_time']);
}

arsort($tags);
$tags=array_slice($tags,0,30);
$tags=array_keys($tags);//最终标签
$lunbo_news=array_splice($news,50,5);
$hot_news=array_splice($news,30,20);
$site_name=$CONFIG['site_name'];
$site_url=$CONFIG['site_url'];
$js=isset($CONFIG['js'])?$CONFIG['js']:"";
header("Referrer-Policy: no-referrer");
include "views/index.php";











